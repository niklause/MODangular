import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import{ HttpClientModule} from '@angular/common/http'
import { AppComponent } from './app.component';
import { AddUserComponent } from './User/add-user/add-user.component';
import { Routes, RouterModule } from '@angular/router';
import { DeleteUserComponent } from './User/disable-user/delete-user.component';

import { HeaderComponent } from './header/header.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LoginComponent } from './login/login.component';
import { AddCourseComponent } from './Courses/add-course/add-course.component';
import { DisableCourseComponent } from './Courses/disable-course/disable-course.component';
import { OperationListComponent } from './Admin/operation-list/operation-list.component';
const appRoutes:Routes=[
  {path:'adminHome',component:HomePageComponent},
  {path:'addUser',component:AddUserComponent},
  {path:'deleteUser',component:DeleteUserComponent},
  {path:'addCourse',component:AddCourseComponent},
  {path:'disableCourse',component:DisableCourseComponent},
  ];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddUserComponent,
    DeleteUserComponent,
    HeaderComponent,
    HomePageComponent,
    AddCourseComponent,
    DisableCourseComponent,
    OperationListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
