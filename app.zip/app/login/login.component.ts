import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  roles=['Select A User','Learner','Mentor','Admin']
  roleSelected:string=''

  constructor(private route:Router) { }

  ngOnInit(): void {
  }
  onRoleSelected(event:any)
  {
     this.roleSelected=(<HTMLSelectElement>event.target).value;
     console.log(this.roleSelected)
  }
  toUserDashboard()
  {
    if(this.roleSelected==='Admin')
    {
      this.route.navigate['./adminHome'];
    }

  }
}
