import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private httpObject:HttpClient){}
  onPost(httpdata:{title:string,content:string})
  {
        this.httpObject.post('https://http-demo-58ed1.firebaseio.com/posts.json',httpdata).subscribe(
          responseData=>
          {
            console.log('Vinayak')
            console.log(responseData);
          })
  }
  
}
