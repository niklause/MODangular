import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disable-course',
  templateUrl: './disable-course.component.html',
  styleUrls: ['./disable-course.component.css']
})
export class DisableCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
