import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {
  roles=['Select A User','Learner','Mentor']
  selectedRole:string='';
  roleNotSelected=true

  constructor() { }

  ngOnInit(): void {
  }
  getRole(event:any)
  {
    this.selectedRole=(<HTMLSelectElement>event.target).value;
      
      if(this.selectedRole==='Select A User')
      {
        this.selectedRole=''
        this.roleNotSelected=true
      }
      else
      {
        this.roleNotSelected=false
      }
      console.log(this.selectedRole)
  }

}
