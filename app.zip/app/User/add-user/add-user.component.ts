import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  roles=['Select A User','Learner','Mentor']
  roleSelected:string=''

  constructor() { }

  ngOnInit(): void {
  }
  onRoleSelected(event:any)
  {
     this.roleSelected=(<HTMLSelectElement>event.target).value;
     console.log(this.roleSelected)
  }

}
