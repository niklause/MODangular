import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operation-list',
  templateUrl: './operation-list.component.html',
  styleUrls: ['./operation-list.component.css']
})
export class OperationListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
